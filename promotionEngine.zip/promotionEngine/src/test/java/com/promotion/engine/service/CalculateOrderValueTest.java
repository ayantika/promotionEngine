package com.promotion.engine.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculateOrderValueTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
