package com.promotion.engine.dto;

public class SkuCombination {
	String skuId;
	int countOfItems;

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public int getCountOfItems() {
		return countOfItems;
	}

	public void setCountOfItems(int countOfItems) {
		this.countOfItems = countOfItems;
	}
}
